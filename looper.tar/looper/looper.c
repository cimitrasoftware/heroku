#include <stdio.h>
#include <stdarg.h> 
#include <string.h>
#include <unistd.h>
#include <syslog.h>
#include <signal.h>
unsigned long count;
int doloop;
void sig_handler(int signo)
{
  if (signo == SIGINT){
	  syslog (LOG_INFO, "Terminating due to SIGINT");	
	doloop=0;  
  } 
  if (signo == SIGHUP){
	syslog (LOG_INFO, "Reseting counter.");	
	count=0;  
  } 
}

int main ( int argc, char *argv[] )
{
  int quiet,nice,i,major,minor;
  major=2;
  minor=0;
  i=1;
  quiet=0;
  nice=0;
  doloop=1;
  count=0;
  if (signal(SIGINT, sig_handler) == SIG_ERR)
    printf("\ncan't catch SIGINT\n");
  if (signal(SIGHUP, sig_handler) == SIG_ERR)
    printf("\ncan't catch SIGHUP\n");
  
  openlog ("looper", LOG_CONS | LOG_PID | LOG_NDELAY, LOG_USER);

  syslog (LOG_INFO, "Program started by User %d euid %d", getuid (),geteuid());
  for(i;i<argc;i++){
      if (!strncmp("quiet",argv[i],6)){
	quiet=1;
	syslog (LOG_INFO, "Running silent");
      }
      if (!strncmp("nice",argv[i],5)){
	nice=1;
	syslog (LOG_INFO, "Running nice");
      }
    if (!strncmp("help",argv[i],4) || !strncmp("?",argv[i],1)){
      syslog (LOG_INFO, "Displaying help");
      printf("looper version %d.%d\n",major,minor);
      printf("by: Craig Lindstrom\n");
      printf("    10/21/2015\n");
      printf("purpose:\n");
      printf("  Demonstrate niceness, setuid, signals, syslog.\n");
      printf("  Runs an infinate loop, logs to syslog USER facility.\n");
      printf("  Counter resets on SIGHUP.\n");
      printf("usage: looper [quiet] [nice]\n");
      printf("examples:\n");
      printf("  looper - counts as fast as possible outputing count to stdout\n");
      printf("  looper quiet - counts as fast as possible, no counter output\n");
      printf("  looper nice - counts with a 1/100th second pause between counts\n");
      printf("  looper nice quiet - counts with a 1/100,000th second pause, no counter output\n");
      syslog (LOG_INFO, "Exiting");
      closelog();
      return 0;
    }
 
  }
  printf("Process ID %d\n",getpid());
  printf("Real User ID %d Effective User ID %d\n",getuid(),geteuid());
  printf("Real Group ID %d Effective Group ID %d\n",getgid(),getegid());
  printf("looper help--to display options");
  count=1;
  if (quiet)
  {	
    if (nice){	    
      printf("Running an infinite loop with 1/100,000 second pause between loops ^C to exit\n");
      while(doloop){
	usleep(10);
      }
    }else{
      syslog (LOG_INFO, "Running in mean mode");
      printf("Running a tight infinite loop ^C to exit\n");
      while(doloop){}
    }
  }else
  {
    printf("Press ^C to exit\n");
    while (doloop)
    {
      
      printf ("Loop #  %lu            \r",count);
      fflush(stdout);
      if (nice){
	usleep(10000);
      }
      count++;
    }
  }
  syslog (LOG_INFO, "Exiting");
  closelog();
  return 0;
}
