#!/bin/sh
origdir=$(pwd)
scriptdir="$( cd "$( dirname "$0" )" && pwd )"
cd $scriptdir
be=$(dpkg-query -W -f='${Status}' build-essential)
if [ "$be" != 'install ok installed' ]
then
  echo "Error build-essential packaged not installed.  Install aborted"
  cd $origdir
  exit 1
fi
if [ -f looper ]
then 
  rm looper
fi
echo "Compiling looper"
gcc -o looper looper.c
cr=$?
if [ "$cr" -ne "0" ]
then
  echo "looper compile error, looper not installed"
  cd $origdir
  exit 1
fi
echo "looper compiled"
echo "installing looper to /usr/bin"
if [ "$(id -u)" = "0" ]; then
  cp looper /usr/bin
  if [ ! -f /usr/bin/looper ]
  then
    echo "could not copy looper to /usr/bin"
    cd $origdir
    return 2
  fi
  echo "=========================================="
  echo "looper installed!"
  echo "=========================================="
  looper help
else
  echo "=============================================="
  echo "looper compiled but NOT installed in /usr/bin"
  echo "try running script as root or with sudo"
  echo "=============================================="
fi
cd $origdir
exit 0
